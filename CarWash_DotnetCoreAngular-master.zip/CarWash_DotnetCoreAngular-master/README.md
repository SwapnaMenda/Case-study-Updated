# CarWash_DotnetCoreAngular
The main objective of On-Demand Car Wash application is to simplify the traditional way of going to car service centres by replacing it with online car wash service. The system will be able to handle many services to take care of all customers in a quick manner.

Video Demo of Case Study : https://drive.google.com/file/d/11WkiryUep9UL1W-82p9Y7FQHO4hcAYvU/view?usp=share_link
