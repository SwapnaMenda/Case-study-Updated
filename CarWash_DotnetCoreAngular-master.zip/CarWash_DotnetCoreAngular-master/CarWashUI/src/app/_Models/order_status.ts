export class OrderStatus {
  orderId : any
  status : any
}