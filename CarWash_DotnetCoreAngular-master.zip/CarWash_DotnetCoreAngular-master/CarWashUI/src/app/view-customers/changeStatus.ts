export class UserStatus {
    id : any
  UserStatus : any
}