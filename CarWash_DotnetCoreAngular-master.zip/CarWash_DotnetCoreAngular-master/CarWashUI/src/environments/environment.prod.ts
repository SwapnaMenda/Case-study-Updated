export const environment = {
  production: true,
  baseUrl: "https://carwashapi.azurewebsites.net/api"
};
