﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CarWashApi.Models
{
    public class OrderStatus
    {
        public int OrderId { get; set; }
        public string Status { get; set; }
    }
}
